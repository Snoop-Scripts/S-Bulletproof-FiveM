USE `es_extended`;

--IF YOU USE WEIGHT | Place item in config | line: 27
INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('ITEM_NAME_HERE', 'ITEM_LABEL_HERE', 1)
--EXAMPLE ('bulletproof', 'Bulletproof vest', 1)
;

--IF YOU USE LIMIT | Place item in config | line: 27
INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('ITEM_NAME_HERE', 'ITEM_LABEL_HERE', 1)
--EXAMPLE ('bulletproof', 'Bulletproof vest', 1)
;